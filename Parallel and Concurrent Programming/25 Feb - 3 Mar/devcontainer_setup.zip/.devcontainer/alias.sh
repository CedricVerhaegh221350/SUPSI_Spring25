#!/bin/bash

echo "alias python_gil='python3.13'" >> /root/.bashrc
echo "alias python='python3.13t'" >> /root/.bashrc
echo "alias pip=pip3" >> /root/.bashrc